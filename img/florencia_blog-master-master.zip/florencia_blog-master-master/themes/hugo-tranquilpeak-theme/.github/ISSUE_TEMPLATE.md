<!-- use this template only to report a bug or ask a question -->
<!-- fill this part for bugs reporting or questions -->
### Configuration

 - **Operating system with its version**: 
 - **Browser with its version**:
 - **Hugo version**: <!-- You can get version by typing: hugo version -->
 - **Tranquilpeak version**: <!-- You can find version on package.json -->
 - **Do you reproduce on https://tranquilpeak.kakawait.com demo?**:
 
<!-- fill this part for bugs reporting if needed  -->
### Actual behavior

<!-- fill this part for bugs reporting if needed  -->
### Expected behavior

<!-- fill this part for bugs reporting if needed -->
### Steps to reproduce the behavior