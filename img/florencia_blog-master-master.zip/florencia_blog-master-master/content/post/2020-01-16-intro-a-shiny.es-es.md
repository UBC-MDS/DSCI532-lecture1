---
title: intro a shiny
author: ''
date: '2020-01-16'
slug: es-es
categories: []
tags: []
keywords:
  - tech
---

<!--more-->
